//
//  ViewController.swift
//  CATransformMatrixTest
//
//  Created by Abhay on 27/11/19.
//  Copyright © 2019 Abhay. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

   var  imageView = UIImageView(frame: CGRect(x: -150, y: -150, width: 300, height: 300))
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        
    
    }
    override func viewDidAppear(_ animated: Bool) {
     
        
        CubeGenerate()
        
    }
        
    
    
    func face(with transform:CATransform3D,color:UIColor) -> CALayer
    {
        let face = CALayer()
        face.frame = CGRect(x: -100, y: -100, width: 200, height: 200)
        face.backgroundColor = color.cgColor
        face.transform = transform
        return face
    }
        
    
    func CubeGenerate()
    {
        let cube = CATransformLayer()
       // create the front face
          let transform1 = CATransform3DMakeTranslation(0, 0, 100)
          cube.addSublayer(face(with: transform1, color: .red))

          // create the right-hand face
          var transform2 = CATransform3DMakeTranslation(100, 0, 0)
          transform2 = CATransform3DRotate(transform2, CGFloat.pi / 2, 0, 1, 0)
          cube.addSublayer(face(with: transform2, color: .yellow))

          // create the top face
          var transform3 = CATransform3DMakeTranslation(0, -100, 0)
          transform3 = CATransform3DRotate(transform3, CGFloat.pi / 2, 1, 0, 0)
          cube.addSublayer(face(with: transform3, color: .green))

          // create the bottom face
          var transform4 = CATransform3DMakeTranslation(0, 100, 0)
          transform4 = CATransform3DRotate(transform4, -(CGFloat.pi / 2), 1, 0, 0)
        cube.addSublayer(face(with: transform4, color: .orange))

          // create the left-hand face
          var transform5 = CATransform3DMakeTranslation(-100, 0, 0)
          transform5 = CATransform3DRotate(transform5, -(CGFloat.pi / 2), 0, 1, 0)
          cube.addSublayer(face(with: transform5, color: .cyan))

          // create the back face
          var transform6 = CATransform3DMakeTranslation(0, 0, -100)
          transform6 = CATransform3DRotate(transform6, CGFloat.pi, 0, 1, 0)
          cube.addSublayer(face(with: transform6, color: .magenta))

          // now position the transform layer in the center
          cube.position = CGPoint(x: view.bounds.midX, y: view.bounds.midY)

          // and add the cube to our main view's layer
          view.layer.addSublayer(cube)
        
        //animation
        let anim = CABasicAnimation(keyPath: "transform")
               anim.fromValue = cube.transform
               anim.toValue = CATransform3DMakeRotation(CGFloat.pi, 1, 1, 1)
               anim.duration = 2
               anim.isCumulative = true
               
        anim.repeatCount = .greatestFiniteMagnitude
               cube.add(anim, forKey: "transform")
        
    }
        
    


}
